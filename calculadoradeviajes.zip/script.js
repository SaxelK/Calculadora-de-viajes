function calcularTotal() {
    // Obtener los valores desde los campos de entrada
    let km = parseFloat(document.getElementById('km').value);
    let valorKm = parseFloat(document.getElementById('valorKm').value);
    let viajes = parseInt(document.getElementById('viajes').value);
    let mediosViajes = parseFloat(document.getElementById('mediosViajes').value);

    // Validar los valores ingresados
    if (isNaN(km) || km <= 0 || isNaN(valorKm) || valorKm <= 0 || isNaN(viajes) || viajes < 0 || isNaN(mediosViajes) || mediosViajes < 0) {
        alert("Por favor, ingresa valores válidos.");
        return;
    }

    // Calcular el total de viajes (sumando medios viajes)
    let totalViajes = viajes + (mediosViajes * 0.5);

    // Calcular el total sin descuento
    let totalSinDescuento = km * valorKm * totalViajes;

    // Calcular el 5% de descuento
    let descuento = totalSinDescuento * 0.05;

    // Calcular el total con descuento
    let totalConDescuento = totalSinDescuento - descuento;

    // Mostrar el resultado en la página
    document.getElementById("resultado").innerHTML = `
        Kilómetros: ${km} km<br>
        Valor por kilómetro: $${valorKm}<br>
        Viajes completos: ${viajes}<br>
        Medios viajes: ${mediosViajes} (equivale a ${mediosViajes * 0.5} viajes completos)<br>
        Total de viajes: ${totalViajes}<br>
        Total sin descuento: $${totalSinDescuento.toFixed(2)}<br>
        Descuento (5%): $${descuento.toFixed(2)}<br>
        <strong>Total a pagar con descuento: $${totalConDescuento.toFixed(2)}</strong>
    `;
}
